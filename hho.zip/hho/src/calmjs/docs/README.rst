Documentation
=============

To be done.  For now please refer to developer's docs.
