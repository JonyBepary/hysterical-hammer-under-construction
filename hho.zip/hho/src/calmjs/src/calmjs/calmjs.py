from __future__ import absolute_import

if __name__ == '__main__':
    from calmjs import runtime
    runtime.main()
